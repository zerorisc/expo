#!/bin/bash

LD_PRELOAD=/lib/x86_64-linux-gnu/libudev.so.1 vivado -mode batch -nojournal -nolog -script synthesize.tcl
